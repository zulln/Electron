// hello.cc
#include <node.h>

using namespace v8;


//Prereq test
void PerformPrerequisiteTests()


void VMCheck(const FunctionCallbackInfo<Value>& args) {


}


void InternetCheck(const FunctionCallbackInfo<Value>& args) {

}


void DiskSpaceCheck(const FunctionCallbackInfo<Value>& args) {

}


void AutoUpdateCheck(const FunctionCallbackInfo<Value>& args) {

}


void LocalInstallationCheck(const FunctionCallbackInfo<Value>& args) {

}


void OSVersionCheck(const FunctionCallbackInfo<Value>& args) {

}

void Method2(const FunctionCallbackInfo<Value>& args) {
  Isolate* isolate = Isolate::GetCurrent();
  HandleScope scope(isolate);
  args.GetReturnValue().Set(String::NewFromUtf8(isolate, "method 2"));
}

void Method(const FunctionCallbackInfo<Value>& args) {
  Isolate* isolate = Isolate::GetCurrent();
  HandleScope scope(isolate);
  args.GetReturnValue().Set(String::NewFromUtf8(isolate, "world MacOSX"));
}

void init(Handle<Object> exports) {
  NODE_SET_METHOD(exports, "hello", Method);
  NODE_SET_METHOD(exports, "method2", Method2);
  NODE_SET_METHOD(exports, "OSVersionCheck", OSVersionCheck);
}

NODE_MODULE(addonMac, init)

