// hello.js
var addon = require('./build/Release/addonMac');

console.log(addon.hello()); // 'world'
